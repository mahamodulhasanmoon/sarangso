"use strict";(()=>{var e={};e.id=447,e.ids=[447],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4770:e=>{e.exports=require("crypto")},5315:e=>{e.exports=require("path")},6184:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>h,patchFetch:()=>g,requestAsyncStorage:()=>u,routeModule:()=>p,serverHooks:()=>N,staticGenerationAsyncStorage:()=>l});var s={};r.r(s),r.d(s,{DELETE:()=>c,GET:()=>E,PUT:()=>d});var a=r(9303),o=r(8716),i=r(670),T=r(7070),n=r(2512);async function E(e,{params:t}){try{let e=Number.parseInt(t.id),r=n.Z.prepare("SELECT * FROM custom_pages WHERE id = ?").get(e);if(!r)return T.NextResponse.json({error:"Post not found"},{status:404});return T.NextResponse.json({post:r})}catch(e){return console.error("Database error:",e),T.NextResponse.json({error:"Failed to fetch Page"},{status:500})}}async function c(e,{params:t}){try{let e=Number.parseInt(t.id);return n.Z.prepare("DELETE FROM custom_pages WHERE id = ?").run(e),T.NextResponse.json({success:!0})}catch(e){return console.error("Database error:",e),T.NextResponse.json({error:"Failed to delete page"},{status:500})}}async function d(e,{params:t}){try{let{title:r,slug:s,content:a,status:o,seoTitle:i,seoDescription:E}=await e.json(),c=Number.parseInt(t.id);n.Z.prepare(`
      UPDATE custom_pages 
      SET title = ?, slug = ?, content = ?, status = ?, seo_title = ?, seo_description = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(r,s,a,o,i,E,c);let d=n.Z.prepare("SELECT * FROM custom_pages WHERE id = ?").get(c);return T.NextResponse.json({success:!0,page:d})}catch(e){return console.error("Database error:",e),T.NextResponse.json({error:"Failed to update page"},{status:500})}}let p=new a.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/pages/[id]/route",pathname:"/api/pages/[id]",filename:"route",bundlePath:"app/api/pages/[id]/route"},resolvedPagePath:"/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/api/pages/[id]/route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:u,staticGenerationAsyncStorage:l,serverHooks:N}=p,h="/api/pages/[id]/route";function g(){return(0,i.patchFetch)({serverHooks:N,staticGenerationAsyncStorage:l})}},2512:(e,t,r)=>{r.d(t,{Z:()=>c,x:()=>E});var s=r(8691);let a=require("better-sqlite3");var o=r.n(a),i=r(5315);let T=r.n(i)().join(process.cwd(),"data","sarangsho.db"),n=new(o())(T);function E(){n.exec(`
    CREATE TABLE IF NOT EXISTS blog_posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      excerpt TEXT,
      content TEXT NOT NULL,
      thumbnail TEXT,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      tags TEXT,
      author TEXT DEFAULT 'Admin',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      published_at DATETIME
    )
  `),n.exec(`
    CREATE TABLE IF NOT EXISTS custom_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      content TEXT NOT NULL,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),n.exec(`
    CREATE TABLE IF NOT EXISTS screenshots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      image_url TEXT NOT NULL,
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),n.exec(`
    CREATE TABLE IF NOT EXISTS site_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      setting_key TEXT UNIQUE NOT NULL,
      setting_value TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),n.exec(`
    CREATE TABLE IF NOT EXISTS app_features (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      icon TEXT,
      gradient TEXT,
      sort_order INTEGER DEFAULT 0,
      is_active BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),n.exec(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      email TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    )
  `),function(){if(0===n.prepare("SELECT COUNT(*) as count FROM admin_users WHERE username = ?").get("admin").count){let e=s.ZP.hashSync("admin123",10);n.prepare("INSERT INTO admin_users (username, password_hash, email) VALUES (?, ?, ?)").run("admin",e,"admin@sarangsho.com")}let e=n.prepare("INSERT OR IGNORE INTO site_settings (setting_key, setting_value) VALUES (?, ?)");if([["site_name","Sarangsho"],["site_description","Swipe through the latest trusted news"],["seo_title","Sarangsho - Latest Trusted News"],["seo_description","Stay informed with Sarangsho. Swipe through the latest trusted news from verified sources worldwide."],["contact_email","hello@sarangsho.com"],["contact_phone","+1 (555) 123-4567"],["contact_address","123 News Street, Digital City, DC 12345"],["social_facebook",""],["social_twitter",""],["social_instagram",""],["social_linkedin",""],["google_analytics",""],["meta_keywords","news, journalism, mobile news, trusted sources"]].forEach(([t,r])=>{e.run(t,r)}),0===n.prepare("SELECT COUNT(*) as count FROM app_features").get().count){let e=n.prepare("INSERT INTO app_features (title, description, icon, gradient, sort_order) VALUES (?, ?, ?, ?, ?)");e.run("Swipe to Explore","Navigate through news stories with intuitive TikTok-style swiping. Discover content effortlessly with vertical scrolling.","Smartphone","from-blue-500 to-cyan-500",1),e.run("Discover by Category","Find news that matters to you. Browse by politics, technology, sports, entertainment, and more specialized categories.","Search","from-purple-500 to-pink-500",2),e.run("Global News Search","Search for any news topic from around the world. Get instant access to breaking news and trending stories.","Zap","from-green-500 to-teal-500",3),e.run("Trusted Sources Only","All news comes from verified, credible sources. We fact-check and curate content to ensure reliability and accuracy.","Shield","from-orange-500 to-red-500",4)}if(0===n.prepare("SELECT COUNT(*) as count FROM screenshots").get().count){let e=n.prepare("INSERT INTO screenshots (title, description, image_url, sort_order) VALUES (?, ?, ?, ?)");e.run("Home Feed","Swipe through curated news stories","/placeholder.svg?height=600&width=300",1),e.run("Categories","Browse news by topic","/placeholder.svg?height=600&width=300",2),e.run("Search","Find specific news and topics","/placeholder.svg?height=600&width=300",3),e.run("Article View","Read full articles with rich media","/placeholder.svg?height=600&width=300",4),e.run("Bookmarks","Save articles for later reading","/placeholder.svg?height=600&width=300",5)}}()}n.pragma("foreign_keys = ON");let c=n}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[276,691,972],()=>r(6184));module.exports=s})();