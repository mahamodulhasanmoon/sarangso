"use strict";(()=>{var e={};e.id=616,e.ids=[616],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4770:e=>{e.exports=require("crypto")},5315:e=>{e.exports=require("path")},8978:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>N,patchFetch:()=>h,requestAsyncStorage:()=>u,routeModule:()=>c,serverHooks:()=>p,staticGenerationAsyncStorage:()=>l});var s={};r.r(s),r.d(s,{GET:()=>E,PUT:()=>d});var a=r(9303),i=r(8716),o=r(670),n=r(7070),T=r(2512);async function E(){try{let e=T.Z.prepare("SELECT username, email, last_login FROM admin_users WHERE username = ?").get("admin");if(!e)return n.NextResponse.json({error:"User not found"},{status:404});return n.NextResponse.json({profile:{username:e.username,email:e.email,lastLogin:e.last_login}})}catch(e){return console.error("Database error:",e),n.NextResponse.json({error:"Failed to fetch profile"},{status:500})}}async function d(e){try{let{username:t,email:r}=await e.json();if(!t||!r)return n.NextResponse.json({error:"Username and email are required"},{status:400});return T.Z.prepare(`
      UPDATE admin_users 
      SET username = ?, email = ?
      WHERE username = 'admin'
    `).run(t,r),n.NextResponse.json({success:!0,message:"Profile updated successfully"})}catch(e){return console.error("Database error:",e),n.NextResponse.json({error:"Failed to update profile"},{status:500})}}(0,T.x)();let c=new a.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/admin/profile/route",pathname:"/api/admin/profile",filename:"route",bundlePath:"app/api/admin/profile/route"},resolvedPagePath:"/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/api/admin/profile/route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:u,staticGenerationAsyncStorage:l,serverHooks:p}=c,N="/api/admin/profile/route";function h(){return(0,o.patchFetch)({serverHooks:p,staticGenerationAsyncStorage:l})}},2512:(e,t,r)=>{r.d(t,{Z:()=>d,x:()=>E});var s=r(8691);let a=require("better-sqlite3");var i=r.n(a),o=r(5315);let n=r.n(o)().join(process.cwd(),"data","sarangsho.db"),T=new(i())(n);function E(){T.exec(`
    CREATE TABLE IF NOT EXISTS blog_posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      excerpt TEXT,
      content TEXT NOT NULL,
      thumbnail TEXT,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      tags TEXT,
      author TEXT DEFAULT 'Admin',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      published_at DATETIME
    )
  `),T.exec(`
    CREATE TABLE IF NOT EXISTS custom_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      content TEXT NOT NULL,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),T.exec(`
    CREATE TABLE IF NOT EXISTS screenshots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      image_url TEXT NOT NULL,
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),T.exec(`
    CREATE TABLE IF NOT EXISTS site_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      setting_key TEXT UNIQUE NOT NULL,
      setting_value TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),T.exec(`
    CREATE TABLE IF NOT EXISTS app_features (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      icon TEXT,
      gradient TEXT,
      sort_order INTEGER DEFAULT 0,
      is_active BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),T.exec(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      email TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    )
  `),function(){if(0===T.prepare("SELECT COUNT(*) as count FROM admin_users WHERE username = ?").get("admin").count){let e=s.ZP.hashSync("admin123",10);T.prepare("INSERT INTO admin_users (username, password_hash, email) VALUES (?, ?, ?)").run("admin",e,"admin@sarangsho.com")}let e=T.prepare("INSERT OR IGNORE INTO site_settings (setting_key, setting_value) VALUES (?, ?)");if([["site_name","Sarangsho"],["site_description","Swipe through the latest trusted news"],["seo_title","Sarangsho - Latest Trusted News"],["seo_description","Stay informed with Sarangsho. Swipe through the latest trusted news from verified sources worldwide."],["contact_email","hello@sarangsho.com"],["contact_phone","+1 (555) 123-4567"],["contact_address","123 News Street, Digital City, DC 12345"],["social_facebook",""],["social_twitter",""],["social_instagram",""],["social_linkedin",""],["google_analytics",""],["meta_keywords","news, journalism, mobile news, trusted sources"]].forEach(([t,r])=>{e.run(t,r)}),0===T.prepare("SELECT COUNT(*) as count FROM app_features").get().count){let e=T.prepare("INSERT INTO app_features (title, description, icon, gradient, sort_order) VALUES (?, ?, ?, ?, ?)");e.run("Swipe to Explore","Navigate through news stories with intuitive TikTok-style swiping. Discover content effortlessly with vertical scrolling.","Smartphone","from-blue-500 to-cyan-500",1),e.run("Discover by Category","Find news that matters to you. Browse by politics, technology, sports, entertainment, and more specialized categories.","Search","from-purple-500 to-pink-500",2),e.run("Global News Search","Search for any news topic from around the world. Get instant access to breaking news and trending stories.","Zap","from-green-500 to-teal-500",3),e.run("Trusted Sources Only","All news comes from verified, credible sources. We fact-check and curate content to ensure reliability and accuracy.","Shield","from-orange-500 to-red-500",4)}if(0===T.prepare("SELECT COUNT(*) as count FROM screenshots").get().count){let e=T.prepare("INSERT INTO screenshots (title, description, image_url, sort_order) VALUES (?, ?, ?, ?)");e.run("Home Feed","Swipe through curated news stories","/placeholder.svg?height=600&width=300",1),e.run("Categories","Browse news by topic","/placeholder.svg?height=600&width=300",2),e.run("Search","Find specific news and topics","/placeholder.svg?height=600&width=300",3),e.run("Article View","Read full articles with rich media","/placeholder.svg?height=600&width=300",4),e.run("Bookmarks","Save articles for later reading","/placeholder.svg?height=600&width=300",5)}}()}T.pragma("foreign_keys = ON");let d=T}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[276,691,972],()=>r(8978));module.exports=s})();