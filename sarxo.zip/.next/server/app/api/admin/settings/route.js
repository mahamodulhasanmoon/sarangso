"use strict";(()=>{var e={};e.id=80,e.ids=[80],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4770:e=>{e.exports=require("crypto")},5315:e=>{e.exports=require("path")},5322:(e,t,s)=>{s.r(t),s.d(t,{originalPathname:()=>g,patchFetch:()=>_,requestAsyncStorage:()=>d,routeModule:()=>l,serverHooks:()=>u,staticGenerationAsyncStorage:()=>p});var a={};s.r(a),s.d(a,{GET:()=>T,POST:()=>E});var i=s(9303),o=s(8716),r=s(670),n=s(7070),c=s(2512);async function T(){try{let e=c.Z.prepare("SELECT setting_key, setting_value FROM site_settings").all(),t={siteName:"",appStoreLink:"",playStoreLink:"",siteDescription:"",seoTitle:"",seoDescription:"",logo:"",favicon:"",heroImage:"",contactEmail:"",contactPhone:"",contactAddress:"",socialFacebook:"",socialTwitter:"",socialInstagram:"",socialLinkedin:"",googleAnalytics:"",metaKeywords:"",footerDescription:"",Copyright:"",tagLine:""},s={site_name:"siteName",app_store_link:"appStoreLink",play_store_link:"playStoreLink",site_description:"siteDescription",seo_title:"seoTitle",seo_description:"seoDescription",logo:"logo",favicon:"favicon",hero_image:"heroImage",contact_email:"contactEmail",contact_phone:"contactPhone",contact_address:"contactAddress",social_facebook:"socialFacebook",social_twitter:"socialTwitter",social_instagram:"socialInstagram",social_linkedin:"socialLinkedin",google_analytics:"googleAnalytics",meta_keywords:"metaKeywords",footer_description:"footerDescription",copyright:"Copyright",tag_line:"tagLine"};return e.forEach(e=>{let a=s[e.setting_key];a&&(t[a]=e.setting_value||"")}),n.NextResponse.json({settings:t})}catch(e){return console.error("Database error:",e),n.NextResponse.json({error:"Failed to fetch settings"},{status:500})}}async function E(e){try{let t=await e.json(),s=[["site_name",t.siteName],["app_store_link",t.appStoreLink],["play_store_link",t.playStoreLink],["site_description",t.siteDescription],["seo_title",t.seoTitle],["seo_description",t.seoDescription],["logo",t.logo],["favicon",t.favicon],["hero_image",t.heroImage],["contact_email",t.contactEmail],["contact_phone",t.contactPhone],["contact_address",t.contactAddress],["social_facebook",t.socialFacebook],["social_twitter",t.socialTwitter],["social_instagram",t.socialInstagram],["social_linkedin",t.socialLinkedin],["google_analytics",t.googleAnalytics],["meta_keywords",t.metaKeywords],["footer_description",t.footerDescription],["copyright",t.Copyright||`\xa9 ${new Date().getFullYear()} Sarangsho`],["tag_line",t.tagLine||"Swipe through the latest trusted news"]],a=c.Z.prepare(`
      INSERT OR REPLACE INTO site_settings (setting_key, setting_value, updated_at)
      VALUES (?, ?, CURRENT_TIMESTAMP)
    `);return c.Z.transaction(()=>{s.forEach(([e,t])=>{a.run(e,t||"")})})(),n.NextResponse.json({success:!0,message:"Settings saved successfully"})}catch(e){return console.error("Database error:",e),n.NextResponse.json({error:"Failed to save settings"},{status:500})}}(0,c.x)();let l=new i.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/admin/settings/route",pathname:"/api/admin/settings",filename:"route",bundlePath:"app/api/admin/settings/route"},resolvedPagePath:"/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/api/admin/settings/route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:d,staticGenerationAsyncStorage:p,serverHooks:u}=l,g="/api/admin/settings/route";function _(){return(0,r.patchFetch)({serverHooks:u,staticGenerationAsyncStorage:p})}},2512:(e,t,s)=>{s.d(t,{Z:()=>E,x:()=>T});var a=s(8691);let i=require("better-sqlite3");var o=s.n(i),r=s(5315);let n=s.n(r)().join(process.cwd(),"data","sarangsho.db"),c=new(o())(n);function T(){c.exec(`
    CREATE TABLE IF NOT EXISTS blog_posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      excerpt TEXT,
      content TEXT NOT NULL,
      thumbnail TEXT,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      tags TEXT,
      author TEXT DEFAULT 'Admin',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      published_at DATETIME
    )
  `),c.exec(`
    CREATE TABLE IF NOT EXISTS custom_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      content TEXT NOT NULL,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),c.exec(`
    CREATE TABLE IF NOT EXISTS screenshots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      image_url TEXT NOT NULL,
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),c.exec(`
    CREATE TABLE IF NOT EXISTS site_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      setting_key TEXT UNIQUE NOT NULL,
      setting_value TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),c.exec(`
    CREATE TABLE IF NOT EXISTS app_features (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      icon TEXT,
      gradient TEXT,
      sort_order INTEGER DEFAULT 0,
      is_active BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),c.exec(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      email TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    )
  `),function(){if(0===c.prepare("SELECT COUNT(*) as count FROM admin_users WHERE username = ?").get("admin").count){let e=a.ZP.hashSync("admin123",10);c.prepare("INSERT INTO admin_users (username, password_hash, email) VALUES (?, ?, ?)").run("admin",e,"admin@sarangsho.com")}let e=c.prepare("INSERT OR IGNORE INTO site_settings (setting_key, setting_value) VALUES (?, ?)");if([["site_name","Sarangsho"],["site_description","Swipe through the latest trusted news"],["seo_title","Sarangsho - Latest Trusted News"],["seo_description","Stay informed with Sarangsho. Swipe through the latest trusted news from verified sources worldwide."],["contact_email","hello@sarangsho.com"],["contact_phone","+1 (555) 123-4567"],["contact_address","123 News Street, Digital City, DC 12345"],["social_facebook",""],["social_twitter",""],["social_instagram",""],["social_linkedin",""],["google_analytics",""],["meta_keywords","news, journalism, mobile news, trusted sources"]].forEach(([t,s])=>{e.run(t,s)}),0===c.prepare("SELECT COUNT(*) as count FROM app_features").get().count){let e=c.prepare("INSERT INTO app_features (title, description, icon, gradient, sort_order) VALUES (?, ?, ?, ?, ?)");e.run("Swipe to Explore","Navigate through news stories with intuitive TikTok-style swiping. Discover content effortlessly with vertical scrolling.","Smartphone","from-blue-500 to-cyan-500",1),e.run("Discover by Category","Find news that matters to you. Browse by politics, technology, sports, entertainment, and more specialized categories.","Search","from-purple-500 to-pink-500",2),e.run("Global News Search","Search for any news topic from around the world. Get instant access to breaking news and trending stories.","Zap","from-green-500 to-teal-500",3),e.run("Trusted Sources Only","All news comes from verified, credible sources. We fact-check and curate content to ensure reliability and accuracy.","Shield","from-orange-500 to-red-500",4)}if(0===c.prepare("SELECT COUNT(*) as count FROM screenshots").get().count){let e=c.prepare("INSERT INTO screenshots (title, description, image_url, sort_order) VALUES (?, ?, ?, ?)");e.run("Home Feed","Swipe through curated news stories","/placeholder.svg?height=600&width=300",1),e.run("Categories","Browse news by topic","/placeholder.svg?height=600&width=300",2),e.run("Search","Find specific news and topics","/placeholder.svg?height=600&width=300",3),e.run("Article View","Read full articles with rich media","/placeholder.svg?height=600&width=300",4),e.run("Bookmarks","Save articles for later reading","/placeholder.svg?height=600&width=300",5)}}()}c.pragma("foreign_keys = ON");let E=c}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),a=t.X(0,[276,691,972],()=>s(5322));module.exports=a})();