(()=>{var e={};e.id=42,e.ids=[42],e.modules={2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4770:e=>{"use strict";e.exports=require("crypto")},5315:e=>{"use strict";e.exports=require("path")},9158:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>i.a,__next_app__:()=>p,originalPathname:()=>l,pages:()=>c,routeModule:()=>T,tree:()=>d}),r(160),r(5512),r(6083),r(5866);var n=r(3191),o=r(8716),s=r(7922),i=r.n(s),a=r(5231),u={};for(let e in a)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(u[e]=()=>a[e]);r.d(t,u);let d=["",{children:["[slug]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,160)),"/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/[slug]/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,5512)),"/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,6083)),"/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/error.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,5866,23)),"next/dist/client/components/not-found-error"]}],c=["/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/[slug]/page.tsx"],l="/[slug]/page",p={require:r,loadChunk:()=>Promise.resolve()},T=new n.AppPageRouteModule({definition:{kind:o.x.APP_PAGE,page:"/[slug]/page",pathname:"/[slug]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},7311:(e,t,r)=>{Promise.resolve().then(r.bind(r,2600)),Promise.resolve().then(r.bind(r,2597)),Promise.resolve().then(r.t.bind(r,9404,23))},160:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>T,generateMetadata:()=>p});var n=r(9510),o=r(8585),s=r(7371),i=r(9755),a=r(9019),u=r(5126),d=r(3878),c=r(2512);(0,c.x)();let l=async e=>{try{return c.Z.prepare(`
      SELECT * FROM custom_pages 
      WHERE slug = ? AND status = 'published'
    `).get(e)}catch(e){return console.error("Database error:",e),null}};async function p({params:e}){let t=await l(e.slug);return t?{title:t.seo_title||t.title,description:t.seo_description}:{title:"Page Not Found"}}async function T({params:e}){let t=await l(e.slug);return t||(0,o.notFound)(),(0,n.jsxs)("div",{className:"min-h-screen bg-white",children:[n.jsx(u.w,{}),n.jsx("header",{className:"bg-white border-b pt-20",children:(0,n.jsxs)("div",{className:"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[n.jsx(s.default,{href:"/",children:(0,n.jsxs)(a.z,{variant:"ghost",size:"sm",className:"mb-6",children:[n.jsx(i.Z,{className:"w-4 h-4 mr-2"}),"Back to Home"]})}),n.jsx("h1",{className:"text-4xl font-bold text-gray-900 leading-tight",children:t.title})]})}),n.jsx("div",{className:"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16",children:n.jsx("article",{className:"prose prose-lg max-w-none",dangerouslySetInnerHTML:{__html:t.content}})}),n.jsx(d.$,{})]})}},9019:(e,t,r)=>{"use strict";r.d(t,{z:()=>c});var n=r(9510),o=r(1159),s=r(3025),i=r(6145),a=r(5761),u=r(2386);let d=(0,i.j)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",{variants:{variant:{default:"bg-primary text-primary-foreground hover:bg-primary/90",destructive:"bg-destructive text-destructive-foreground hover:bg-destructive/90",outline:"border border-input bg-background hover:bg-accent hover:text-accent-foreground",secondary:"bg-secondary text-secondary-foreground hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-10 px-4 py-2",sm:"h-9 rounded-md px-3",lg:"h-11 rounded-md px-8",icon:"h-10 w-10"}},defaultVariants:{variant:"default",size:"default"}}),c=o.forwardRef(({className:e,variant:t,size:r,asChild:o=!1,...i},c)=>{let l=o?s.g7:"button";return n.jsx(l,{className:function(...e){return(0,u.m6)((0,a.W)(e))}(d({variant:t,size:r,className:e})),ref:c,...i})});c.displayName="Button"},2512:(e,t,r)=>{"use strict";r.d(t,{Z:()=>c,x:()=>d});var n=r(8691);let o=require("better-sqlite3");var s=r.n(o),i=r(5315);let a=r.n(i)().join(process.cwd(),"data","sarangsho.db"),u=new(s())(a);function d(){u.exec(`
    CREATE TABLE IF NOT EXISTS blog_posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      excerpt TEXT,
      content TEXT NOT NULL,
      thumbnail TEXT,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      tags TEXT,
      author TEXT DEFAULT 'Admin',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      published_at DATETIME
    )
  `),u.exec(`
    CREATE TABLE IF NOT EXISTS custom_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      content TEXT NOT NULL,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),u.exec(`
    CREATE TABLE IF NOT EXISTS screenshots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      image_url TEXT NOT NULL,
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),u.exec(`
    CREATE TABLE IF NOT EXISTS site_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      setting_key TEXT UNIQUE NOT NULL,
      setting_value TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),u.exec(`
    CREATE TABLE IF NOT EXISTS app_features (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      icon TEXT,
      gradient TEXT,
      sort_order INTEGER DEFAULT 0,
      is_active BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),u.exec(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      email TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    )
  `),function(){if(0===u.prepare("SELECT COUNT(*) as count FROM admin_users WHERE username = ?").get("admin").count){let e=n.ZP.hashSync("admin123",10);u.prepare("INSERT INTO admin_users (username, password_hash, email) VALUES (?, ?, ?)").run("admin",e,"admin@sarangsho.com")}let e=u.prepare("INSERT OR IGNORE INTO site_settings (setting_key, setting_value) VALUES (?, ?)");if([["site_name","Sarangsho"],["site_description","Swipe through the latest trusted news"],["seo_title","Sarangsho - Latest Trusted News"],["seo_description","Stay informed with Sarangsho. Swipe through the latest trusted news from verified sources worldwide."],["contact_email","hello@sarangsho.com"],["contact_phone","+1 (555) 123-4567"],["contact_address","123 News Street, Digital City, DC 12345"],["social_facebook",""],["social_twitter",""],["social_instagram",""],["social_linkedin",""],["google_analytics",""],["meta_keywords","news, journalism, mobile news, trusted sources"]].forEach(([t,r])=>{e.run(t,r)}),0===u.prepare("SELECT COUNT(*) as count FROM app_features").get().count){let e=u.prepare("INSERT INTO app_features (title, description, icon, gradient, sort_order) VALUES (?, ?, ?, ?, ?)");e.run("Swipe to Explore","Navigate through news stories with intuitive TikTok-style swiping. Discover content effortlessly with vertical scrolling.","Smartphone","from-blue-500 to-cyan-500",1),e.run("Discover by Category","Find news that matters to you. Browse by politics, technology, sports, entertainment, and more specialized categories.","Search","from-purple-500 to-pink-500",2),e.run("Global News Search","Search for any news topic from around the world. Get instant access to breaking news and trending stories.","Zap","from-green-500 to-teal-500",3),e.run("Trusted Sources Only","All news comes from verified, credible sources. We fact-check and curate content to ensure reliability and accuracy.","Shield","from-orange-500 to-red-500",4)}if(0===u.prepare("SELECT COUNT(*) as count FROM screenshots").get().count){let e=u.prepare("INSERT INTO screenshots (title, description, image_url, sort_order) VALUES (?, ?, ?, ?)");e.run("Home Feed","Swipe through curated news stories","/placeholder.svg?height=600&width=300",1),e.run("Categories","Browse news by topic","/placeholder.svg?height=600&width=300",2),e.run("Search","Find specific news and topics","/placeholder.svg?height=600&width=300",3),e.run("Article View","Read full articles with rich media","/placeholder.svg?height=600&width=300",4),e.run("Bookmarks","Save articles for later reading","/placeholder.svg?height=600&width=300",5)}}()}u.pragma("foreign_keys = ON");let c=u},8585:(e,t,r)=>{"use strict";var n=r(1085);r.o(n,"notFound")&&r.d(t,{notFound:function(){return n.notFound}})},1085:(e,t,r)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{ReadonlyURLSearchParams:function(){return i},RedirectType:function(){return n.RedirectType},notFound:function(){return o.notFound},permanentRedirect:function(){return n.permanentRedirect},redirect:function(){return n.redirect}});let n=r(3953),o=r(6399);class s extends Error{constructor(){super("Method unavailable on `ReadonlyURLSearchParams`. Read more: https://nextjs.org/docs/app/api-reference/functions/use-search-params#updating-searchparams")}}class i extends URLSearchParams{append(){throw new s}delete(){throw new s}set(){throw new s}sort(){throw new s}}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},6399:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{isNotFoundError:function(){return o},notFound:function(){return n}});let r="NEXT_NOT_FOUND";function n(){let e=Error(r);throw e.digest=r,e}function o(e){return"object"==typeof e&&null!==e&&"digest"in e&&e.digest===r}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},8586:(e,t)=>{"use strict";var r;Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"RedirectStatusCode",{enumerable:!0,get:function(){return r}}),function(e){e[e.SeeOther=303]="SeeOther",e[e.TemporaryRedirect=307]="TemporaryRedirect",e[e.PermanentRedirect=308]="PermanentRedirect"}(r||(r={})),("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},3953:(e,t,r)=>{"use strict";var n;Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{RedirectType:function(){return n},getRedirectError:function(){return u},getRedirectStatusCodeFromError:function(){return E},getRedirectTypeFromError:function(){return T},getURLFromRedirectError:function(){return p},isRedirectError:function(){return l},permanentRedirect:function(){return c},redirect:function(){return d}});let o=r(4580),s=r(2934),i=r(8586),a="NEXT_REDIRECT";function u(e,t,r){void 0===r&&(r=i.RedirectStatusCode.TemporaryRedirect);let n=Error(a);n.digest=a+";"+t+";"+e+";"+r+";";let s=o.requestAsyncStorage.getStore();return s&&(n.mutableCookies=s.mutableCookies),n}function d(e,t){void 0===t&&(t="replace");let r=s.actionAsyncStorage.getStore();throw u(e,t,(null==r?void 0:r.isAction)?i.RedirectStatusCode.SeeOther:i.RedirectStatusCode.TemporaryRedirect)}function c(e,t){void 0===t&&(t="replace");let r=s.actionAsyncStorage.getStore();throw u(e,t,(null==r?void 0:r.isAction)?i.RedirectStatusCode.SeeOther:i.RedirectStatusCode.PermanentRedirect)}function l(e){if("object"!=typeof e||null===e||!("digest"in e)||"string"!=typeof e.digest)return!1;let[t,r,n,o]=e.digest.split(";",4),s=Number(o);return t===a&&("replace"===r||"push"===r)&&"string"==typeof n&&!isNaN(s)&&s in i.RedirectStatusCode}function p(e){return l(e)?e.digest.split(";",3)[2]:null}function T(e){if(!l(e))throw Error("Not a redirect error");return e.digest.split(";",2)[1]}function E(e){if(!l(e))throw Error("Not a redirect error");return Number(e.digest.split(";",4)[3])}(function(e){e.push="push",e.replace="replace"})(n||(n={})),("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[276,691,211,578,271,735],()=>r(9158));module.exports=n})();