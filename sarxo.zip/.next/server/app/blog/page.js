(()=>{var e={};e.id=404,e.ids=[404],e.modules={2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4770:e=>{"use strict";e.exports=require("crypto")},5315:e=>{"use strict";e.exports=require("path")},8433:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>o.a,__next_app__:()=>T,originalPathname:()=>u,pages:()=>c,routeModule:()=>h,tree:()=>d}),r(1918),r(5512),r(6083),r(5866);var s=r(3191),a=r(8716),i=r(7922),o=r.n(i),n=r(5231),l={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>n[e]);r.d(t,l);let d=["",{children:["blog",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,1918)),"/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/blog/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,5512)),"/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,6083)),"/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/error.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,5866,23)),"next/dist/client/components/not-found-error"]}],c=["/media/mahamodulhasan/Projects/BrainicsoftDigital/2025/july/app/app/blog/page.tsx"],u="/blog/page",T={require:r,loadChunk:()=>Promise.resolve()},h=new s.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/blog/page",pathname:"/blog",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},7311:(e,t,r)=>{Promise.resolve().then(r.bind(r,2600)),Promise.resolve().then(r.bind(r,2597)),Promise.resolve().then(r.t.bind(r,9404,23))},1918:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>h,metadata:()=>T});var s=r(9510),a=r(7371),i=r(9755),o=r(2688),n=r(9019),l=r(5126),d=r(3878),c=r(2512);(0,c.x)();let u=async()=>{try{return c.Z.prepare(`
      SELECT id, title, slug, excerpt, thumbnail, published_at, author, tags
      FROM blog_posts 
      WHERE status = 'published' AND published_at IS NOT NULL
      ORDER BY published_at DESC
    `).all()}catch(e){return console.error("Database error:",e),[]}},T={title:"Blog - Sarangsho",description:"Read our latest insights on journalism, technology, and the future of news consumption."};async function h(){let e=await u();return(0,s.jsxs)("div",{className:"min-h-screen bg-white",children:[s.jsx(l.w,{}),s.jsx("header",{className:"bg-white border-b pt-20",children:(0,s.jsxs)("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12",children:[s.jsx(a.default,{href:"/",children:(0,s.jsxs)(n.z,{variant:"ghost",size:"sm",className:"mb-8",children:[s.jsx(i.Z,{className:"w-4 h-4 mr-2"}),"Back to Home"]})}),(0,s.jsxs)("div",{className:"text-center",children:[s.jsx("h1",{className:"text-4xl font-bold text-gray-900 mb-4",children:"Our Blog"}),s.jsx("p",{className:"text-xl text-gray-600 max-w-3xl mx-auto",children:"Stay updated with our thoughts on journalism, technology, and the future of news consumption."})]})]})}),s.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16",children:e.length>0?s.jsx("div",{className:"grid md:grid-cols-2 lg:grid-cols-3 gap-8",children:e.map(e=>(0,s.jsxs)("article",{className:"group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100",children:[s.jsx("div",{className:"aspect-video overflow-hidden",children:s.jsx("img",{src:e.thumbnail||"/placeholder.svg?height=200&width=300",alt:e.title,className:"w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"})}),(0,s.jsxs)("div",{className:"p-6",children:[(0,s.jsxs)("div",{className:"flex items-center text-sm text-gray-500 mb-3",children:[s.jsx(o.Z,{className:"w-4 h-4 mr-2"}),new Date(e.published_at).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"})]}),s.jsx("h2",{className:"text-xl font-semibold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors",children:e.title}),s.jsx("p",{className:"text-gray-600 mb-4 leading-relaxed",children:e.excerpt}),(0,s.jsxs)("div",{className:"flex items-center justify-between",children:[(0,s.jsxs)("span",{className:"text-sm text-gray-500",children:["By ",e.author]}),s.jsx(a.default,{href:`/blog/${e.slug}`,children:s.jsx(n.z,{variant:"ghost",size:"sm",className:"text-blue-600 hover:text-blue-700",children:"Read More →"})})]})]})]},e.id))}):(0,s.jsxs)("div",{className:"text-center py-16",children:[s.jsx("div",{className:"w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4",children:s.jsx(o.Z,{className:"w-8 h-8 text-gray-400"})}),s.jsx("h2",{className:"text-2xl font-bold text-gray-900 mb-2",children:"No blog posts yet"}),s.jsx("p",{className:"text-gray-600 mb-8",children:"Check back soon for our latest insights and articles."}),s.jsx(a.default,{href:"/",children:s.jsx(n.z,{children:"Return to Home"})})]})}),s.jsx(d.$,{})]})}},9019:(e,t,r)=>{"use strict";r.d(t,{z:()=>c});var s=r(9510),a=r(1159),i=r(3025),o=r(6145),n=r(5761),l=r(2386);let d=(0,o.j)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",{variants:{variant:{default:"bg-primary text-primary-foreground hover:bg-primary/90",destructive:"bg-destructive text-destructive-foreground hover:bg-destructive/90",outline:"border border-input bg-background hover:bg-accent hover:text-accent-foreground",secondary:"bg-secondary text-secondary-foreground hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-10 px-4 py-2",sm:"h-9 rounded-md px-3",lg:"h-11 rounded-md px-8",icon:"h-10 w-10"}},defaultVariants:{variant:"default",size:"default"}}),c=a.forwardRef(({className:e,variant:t,size:r,asChild:a=!1,...o},c)=>{let u=a?i.g7:"button";return s.jsx(u,{className:function(...e){return(0,l.m6)((0,n.W)(e))}(d({variant:t,size:r,className:e})),ref:c,...o})});c.displayName="Button"},2512:(e,t,r)=>{"use strict";r.d(t,{Z:()=>c,x:()=>d});var s=r(8691);let a=require("better-sqlite3");var i=r.n(a),o=r(5315);let n=r.n(o)().join(process.cwd(),"data","sarangsho.db"),l=new(i())(n);function d(){l.exec(`
    CREATE TABLE IF NOT EXISTS blog_posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      excerpt TEXT,
      content TEXT NOT NULL,
      thumbnail TEXT,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      tags TEXT,
      author TEXT DEFAULT 'Admin',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      published_at DATETIME
    )
  `),l.exec(`
    CREATE TABLE IF NOT EXISTS custom_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      content TEXT NOT NULL,
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
      seo_title TEXT,
      seo_description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),l.exec(`
    CREATE TABLE IF NOT EXISTS screenshots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      image_url TEXT NOT NULL,
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),l.exec(`
    CREATE TABLE IF NOT EXISTS site_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      setting_key TEXT UNIQUE NOT NULL,
      setting_value TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),l.exec(`
    CREATE TABLE IF NOT EXISTS app_features (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      icon TEXT,
      gradient TEXT,
      sort_order INTEGER DEFAULT 0,
      is_active BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),l.exec(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      email TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    )
  `),function(){if(0===l.prepare("SELECT COUNT(*) as count FROM admin_users WHERE username = ?").get("admin").count){let e=s.ZP.hashSync("admin123",10);l.prepare("INSERT INTO admin_users (username, password_hash, email) VALUES (?, ?, ?)").run("admin",e,"admin@sarangsho.com")}let e=l.prepare("INSERT OR IGNORE INTO site_settings (setting_key, setting_value) VALUES (?, ?)");if([["site_name","Sarangsho"],["site_description","Swipe through the latest trusted news"],["seo_title","Sarangsho - Latest Trusted News"],["seo_description","Stay informed with Sarangsho. Swipe through the latest trusted news from verified sources worldwide."],["contact_email","hello@sarangsho.com"],["contact_phone","+1 (555) 123-4567"],["contact_address","123 News Street, Digital City, DC 12345"],["social_facebook",""],["social_twitter",""],["social_instagram",""],["social_linkedin",""],["google_analytics",""],["meta_keywords","news, journalism, mobile news, trusted sources"]].forEach(([t,r])=>{e.run(t,r)}),0===l.prepare("SELECT COUNT(*) as count FROM app_features").get().count){let e=l.prepare("INSERT INTO app_features (title, description, icon, gradient, sort_order) VALUES (?, ?, ?, ?, ?)");e.run("Swipe to Explore","Navigate through news stories with intuitive TikTok-style swiping. Discover content effortlessly with vertical scrolling.","Smartphone","from-blue-500 to-cyan-500",1),e.run("Discover by Category","Find news that matters to you. Browse by politics, technology, sports, entertainment, and more specialized categories.","Search","from-purple-500 to-pink-500",2),e.run("Global News Search","Search for any news topic from around the world. Get instant access to breaking news and trending stories.","Zap","from-green-500 to-teal-500",3),e.run("Trusted Sources Only","All news comes from verified, credible sources. We fact-check and curate content to ensure reliability and accuracy.","Shield","from-orange-500 to-red-500",4)}if(0===l.prepare("SELECT COUNT(*) as count FROM screenshots").get().count){let e=l.prepare("INSERT INTO screenshots (title, description, image_url, sort_order) VALUES (?, ?, ?, ?)");e.run("Home Feed","Swipe through curated news stories","/placeholder.svg?height=600&width=300",1),e.run("Categories","Browse news by topic","/placeholder.svg?height=600&width=300",2),e.run("Search","Find specific news and topics","/placeholder.svg?height=600&width=300",3),e.run("Article View","Read full articles with rich media","/placeholder.svg?height=600&width=300",4),e.run("Bookmarks","Save articles for later reading","/placeholder.svg?height=600&width=300",5)}}()}l.pragma("foreign_keys = ON");let c=l},2688:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});let s=(0,r(7162).Z)("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]])}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[276,691,211,578,271,735],()=>r(8433));module.exports=s})();